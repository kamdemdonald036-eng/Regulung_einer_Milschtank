% Dateien einlesen
%kalt_fuellbestand = readtable('Kaltwasserwerte_Füllbestand.csv');
%kalt_temperatur = readtable('Kaltwasserwerte_Temperatur.csv');
%warm_fuellbestand = readtable('Warmwasserwerte_Füllbestand.csv');
%warm_temperatur = readtable('Warmwasserwerte_Temperatur.csv');

% Neue Figure erstellen
figure;

% Plot 1: Kaltwasser Füllbestand
subplot(4,1,1); % 4 Zeilen, 1 Spalte, Plot 1
plot(kalt_fuellbestand{:,1}, kalt_fuellbestand{:,2}, 'b', 'LineWidth', 1.5);
xlabel('Zeit');
ylabel('Füllbestand');
title('Kaltwasser Füllbestand');
grid on;

% Plot 2: Kaltwasser Temperatur
subplot(4,1,2); % 4 Zeilen, 1 Spalte, Plot 2
plot(kalt_temperatur{:,1}, kalt_temperatur{:,2}, 'b', 'LineWidth', 1.5);
xlabel('Zeit');
ylabel('Temperatur');
title('Kaltwasser Temperatur');
grid on;

% Plot 3: Warmwasser Füllbestand
subplot(4,1,3); % 4 Zeilen, 1 Spalte, Plot 3
plot(warm_fuellbestand{:,1}, warm_fuellbestand{:,2}, 'b', 'LineWidth', 1.5);
xlabel('Zeit');
ylabel('Füllbestand');
title('Warmwasser Füllbestand');
grid on;

% Plot 4: Warmwasser Temperatur
subplot(4,1,4); % 4 Zeilen, 1 Spalte, Plot 4
plot(warm_temperatur{:,1}, warm_temperatur{:,2}, 'b', 'LineWidth', 1.5);
xlabel('Zeit');
ylabel('Temperatur');
title('Warmwasser Temperatur');
grid on;